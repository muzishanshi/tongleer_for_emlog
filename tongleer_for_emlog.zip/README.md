<img src="https://ws3.sinaimg.cn/large/0078FzW1ly1fswhcipezdj311i0gr7m0.jpg">

# WeiboForEmlog主题

本模板为作者个人原创，使用了Amaze UI中国首个开源 HTML5 跨屏前端框架制作。此模板移植自作者的另一个typecho主题：https://github.com/muzishanshi/tongleer<br />欢迎typecho用户下载使用。

程序有可能会遇到bug不改版本号直接修改代码的时候，所以扫描以下二维码关注公众号“同乐儿”，可直接与作者二呆产生联系，不再为bug烦恼，随时随地解决问题。

<img src="http://me.tongleer.com/content/uploadfile/201706/008b1497454448.png">

# 主题特点
 - 模拟微博主页，适合自媒体站长使用。

 - 可自定义昵称、头像、简介、认证信息等信息

# 使用教程
 - 将本主题里的所有文件放在您网站目录的content/emplates内，注意文件夹名字必须为tongleer。

 - 后台->模板->启用本主题->进入模板设置内配置信息

 - 本主题限个人使用，公开发布请注明原作者：二呆，及链接：http://www.tongleer.com

 - 如果你喜欢这个主题，别忘记给我打赏哦：http://me.tongleer.com/qitao/index.php?payChannel=alipay

# 官方演示
http://joke.tongleer.com

优秀使用者可联系作者QQ:2293338477有机会加入站长大家庭，一起为了世界和平而奋斗。

# 使用问题
 - 如果遇到bug或者使用问题，欢迎给我来email：diamond@tongleer.com
 
 - 作者使用的是php5.6开发，所以如果遇到php版本问题无法使用，请更换php5.6即可。
 
 - 如果您有何意见建议，欢迎告知作者，您的支持是作者无限的动力！

# 版本记录
v1.0.1：第一个版本降世